import funcoes

# inicio do programa
print('\033[31m<\033[31m' * 15, end='')
print('\033[33mAgente de redução de energy\033[m', end='')
print('\033[31m>\033[31\033[0m' * 15)
print()

novamente = True

while novamente == True:

    opcao = int(input('Escolha qual residência vai querer observar(1 | 10): '))
    print()
    if opcao < 1 or opcao > 10:
        while opcao < 1 or opcao > 10:
            opcao = int(input('Digite um valor valido entre 1 e 10: '))
            print()

    #transformar int em id
    opcao_id = funcoes.transformar(opcao)       

    # leitura dos dados
    dataset = funcoes.lerDados(opcao_id)

    # mostra dados da residencia
    print('-' * 10, end='')
    print('Perfil da residência', end='')
    print('-' * 10)
    print('Residência escolhida: {}'.format(opcao_id))
    print('Número de moradores: {}'.format(dataset[0]['numero_moradores']))
    print('Meta de consumo diário: {}'.format(dataset[0]['meta_consumo_diario_kwh']))
    print('Perfil do(s) morador(es): {}'.format(dataset[0]['perfil_morador']))
    equipamentos = []
    indice = 0
    
    for i in dataset:
        equipamentos.append(dataset[indice]['equipamento'])
        indice += 1
    
    print('Iten(s) da residência: {}'.format(equipamentos))
    print('-' * 10)
    print()

    # perceber quais equipamentos são passiveis de mudança
    contexto  = funcoes.perceber(dataset)

    # converter os pesos
    pesos = funcoes.conversao_pesos(dataset)

    # chamadas de funções para fazer estimativa
    recomendacoes_ordenadas = funcoes.calculo_utilidade(contexto, pesos)

    # calculo do consumo atual
    consumo_atual = funcoes.calculo_consumo(dataset)

    # criação do estado
    estado = {
        'residencia' : opcao_id,
        'consumo' : consumo_atual,
        'apresentados': [],
        'aceitos' : [],
        'rejeitados' : [],
        'pendentes' : [],
        'podem_ser_apresentadas' : recomendacoes_ordenadas 
    }

    print('-' * 10, end='')
    print('Sugestões de economia', end='')
    print('-' * 10)
    # mostra sugestões e usuario escolhe
    for opcoes in estado['podem_ser_apresentadas']:
        print('Equipamento ID: {}'.format(opcoes["equipamento_id"]))
        print('Equipamento: {}'.format(opcoes["equipamento"]))
        print('Categoria: {}'.format(opcoes["categoria"]))
        print('Economia potencial diária em kWh: {}'.format(opcoes["economia_potencial_reducao_kwh"]))
        print('Impacto no conforto: {}'.format(opcoes["impacto_conforto_1a5"]))
        print('Flexibilidade para adaptar o uso: {}'.format(opcoes["flexibilidade_reducao_uso_1a5"]))
        print('Esforço necessário: {}'.format(opcoes["esforco_1a5"]))
        print('Utilidade: {:.2f}'.format(opcoes["utilidade"]))
        print('Sugestão do que fazer: {}'.format(opcoes["descricao"]))
        print()

        print("O que deseja fazer com essa sugestão?")
        print('1 - Aceitar')
        print('2 - Rejeitar')
        print('3 - Decidir depois')
        decisao = int(input('Escolha: '))
        print()

        if decisao < 1 or decisao > 3:
            while decisao < 1 or decisao > 3:
                decisao = int(input('Digite um valor valido 1, 2 ou 3: '))
                print()

        if decisao == 1:
            estado['apresentados'].append(opcoes["equipamento_id"])
            estado['aceitos'].append(opcoes["equipamento_id"])
            estado['consumo'] = estado['consumo'] - opcoes["economia_potencial_reducao_kwh"]

            if estado['consumo'] < 0:
                estado['consumo'] = 0
        
        elif decisao == 2:
            estado['apresentados'].append(opcoes["equipamento_id"])
            estado['rejeitados'].append(opcoes["equipamento_id"])

        elif decisao == 3:
            estado['apresentados'].append(opcoes["equipamento_id"])
            estado['pendentes'].append(opcoes["equipamento_id"])

        print('Consumo estimado atualizado: {:.2f} kWh/dia'.format(estado['consumo']))
        print()

    # se houver algum pendente, escolher se quer decidir agora ou não
    if len(estado['pendentes']) > 0:
        print('-' * 10, end='')
        print('Deseja decidir sobre os pendentes?', end='')
        print('-' * 10)

        print('1 - Sim')
        print('2 - Não')
        decisaoPendente = int(input('Escolha: '))
        print()

        if decisaoPendente < 1 or decisaoPendente > 2:
            while decisaoPendente < 1 or decisaoPendente > 2:
                decisaoPendente = int(input('Digite um valor valido 1 ou 2: '))
                print()

        if decisaoPendente == 1:
            while len(estado['pendentes']) > 0:
                atual = estado['pendentes'].pop(0)

                for opcoes in estado['podem_ser_apresentadas']:
                    if atual == opcoes["equipamento_id"]:
                        print('Equipamento ID: {}'.format(opcoes["equipamento_id"]))
                        print('Equipamento: {}'.format(opcoes["equipamento"]))
                        print('Categoria: {}'.format(opcoes["categoria"]))
                        print('Economia potencial diária em kWh: {}'.format(opcoes["economia_potencial_reducao_kwh"]))
                        print('Impacto no conforto: {}'.format(opcoes["impacto_conforto_1a5"]))
                        print('Flexibilidade para adaptar o uso: {}'.format(opcoes["flexibilidade_reducao_uso_1a5"]))
                        print('Esforço necessário: {}'.format(opcoes["esforco_1a5"]))
                        print('Utilidade: {:.2f}'.format(opcoes["utilidade"]))
                        print('Sugestão do que fazer: {}'.format(opcoes["descricao"]))
                        print()
                
                        print("O que deseja fazer com essa sugestão?")
                        print('1 - Aceitar')
                        print('2 - Rejeitar')
                        escolhaPendente = int(input('Escolha: '))
                        print()

                        if escolhaPendente < 1 or escolhaPendente > 2:
                            while escolhaPendente < 1 or escolhaPendente > 2:
                                escolhaPendente = int(input('Digite um valor valido 1 ou 2: '))
                                print()

                        if escolhaPendente == 1:
                            estado['aceitos'].append(opcoes["equipamento_id"])
                            estado['consumo'] = estado['consumo'] - opcoes["economia_potencial_reducao_kwh"]
                
                            if estado['consumo'] < 0:
                                estado['consumo'] = 0
                        
                        elif escolhaPendente == 2:
                            estado['rejeitados'].append(opcoes["equipamento_id"])

                        print('Consumo estimado atualizado: {:.2f} kWh/dia'.format(estado['consumo']))
                        print()

        elif decisaoPendente == 2:
            pass
    
    # converter a meta
    meta = funcoes.converter_meta(dataset)
    
    # mostra feedback/resultado final
    print('-' * 10, end='')
    print('Feedback final', end='')
    print('-' * 10)
    print("Após as suas escolhas, eis aqui o resultado final:")
    print()
    print("Sugestões da residência: {}".format(estado['residencia']))
    print('Prioridades dos moradores:')
    print('Economia: {}'.format(pesos['peso_economia']))
    print('Conforto: {}'.format(pesos['peso_conforto']))
    print('Flexibilidade: {}'.format(pesos['peso_flexibilidade']))
    print('Baixo esforço: {}'.format(pesos['peso_baixo_esforco']))
    print("Sugestões mostradas: {}".format(estado['apresentados']))
    print("Sugestões aceitas: {}".format(estado['aceitos']))
    print("Sugestões rejeitadas: {}".format(estado['rejeitados']))
    print("Sugestões pendentes: {}".format(estado['pendentes']))
    print("Meta de consumo diário: {:.2f}".format(meta))
    print("Consumo anterior: {:.2f}".format(consumo_atual))
    print("Consumo após as escolhas: {:.2f}". format(estado['consumo']))

    diferenca = estado['consumo'] - meta

    if diferenca > 0:
        print("A meta não foi atingida com sucesso! Ainda resta economizar cerca de {:.2f}Kwh".format(diferenca))

    elif diferenca == 0:
        print("A meta foi atingida com sucesso!")

    elif diferenca < 0:
        print("A meta foi atingida com sucesso! Além disso conseguiu economizar cerca de {:.2f}Kwh além da meta".format(abs(diferenca)))

    print()

    # encerra programa ou continua

    print('Deseja ver outra residência?')
    print('1 - Sim')
    print('2 - Não')
    escolha = int(input('Escolha: '))
    print()

    if escolha < 1 or escolha > 2:
        while escolha < 1 or escolha > 2:
            escolha = int(input('Digite um valor valido 1 ou 2: '))
            print()

    if escolha == 1:
        novamente = True
    else:
        novamente = False
