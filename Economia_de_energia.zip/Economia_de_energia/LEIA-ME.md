*Organização do Projeto:*

dados
    - arquivo csv que contém o dataset das residências

funcoes
    - __init__.py : arquivo responsável por fazer a conexão entre os arquivos
    - agente.py : arquivo responsável por conter as funções referente ao agente
    - leituraDados.py : arquivo responsável por conter as funções referente a leitura do arquivo csv e leitura de outros dados

principal : arquivo onde fica a execução do programa

# Todos os exemplos serão utilizando a residência n° 1, mas o procedimento é o mesmo para todas

*agente.py:*

- def conversao_linha_equipamento : função responsável por converter os dados do arquivo csv de texto - int/float/booleano/etc, convertendo apenas os dados que serão de maior uso para o programa posteriormente. Ou seja, as linhas que vinham da residência
como:

reducao_uso : "FALSE"
essencialidade : "essencial"
impacto_conforto_1a5 : "5"
flexibilidade_reducao_uso_1a5 : "1"
esforco_1a5 : "1"

ficavam:

reducao_uso : FALSE
essencialidade : "essencial"
impacto_conforto_1a5 : 5
flexibilidade_reducao_uso_1a5 : 1
esforco_1a5 : 1

- def perceber : função responsável por perceber quais equipamentos são elegíveis para mudanças e quais não são, ou seja, primeiro convertemos os dados que serão usados para decidir se é passível de mudança, através da função 'conversao_linha_equipamento' e após isso guardamos em uma lista os que forem aprovados. Por exemplo:

equipamentos da casa [1, 2, 3, 4, 5, 6]
passíveis de mudança [4, 5, 6]

- def definir_descricao : função responsável por definir uma descrição para o equipamento que foi aprovado como passível de mudança, ou seja, é usado a categoria e nome do equipamento, e com base nisso, é gerado uma breve descrição do que o usuário deve fazer para diminuir a energia. Por exemplo:

equipamento : Geladeira
categoria : cozinha
logo: "Evite abrir a porta frequentemente e verifique se ela está bem fechada."

- def calculo_utilidade : função responsável por calcular a utilidade de cada equipamento passível e gerar uma lista ordenada com base da maior utilidade para a menor utilidade. As contas usadas foram:

nota_economia = 1 + 4 * (economia_potencial / maior_economia_elegivel)
 - economia_potencial = coluna [economia_potencial_reducao_kwh]
 - maior_economia_elegivel = maior valor da coluna [economia_potencial_reducao_kwh] entre os equipamentos passíveis de mudança
 - Exemplo: 
    4 : 0.16 = 1 + 4 * (0.16 / 0.16) = 5
    5 : 0.12 = 1 + 4 * (0.12 / 0.16) = 4
    6 : 0.08 = 1 + 4 * (0.08 / 0.16) = 3

    maior_economia_elegivel = 0.16


nota_conforto = 6 - impacto_conforto_1a5
 - impacto_conforto_1a5 = coluna [impacto_conforto_1a5]
 - Exemplo:
   4 : 2 = 6 - 2 = 4
   5 : 2 = 6 - 2 = 4
   6 : 2 = 6 - 2 = 4

nota_flexibilidade = flexibilidade_reducao_uso_1a5
 - flexibilidade_reducao_uso_1a5 = coluna [flexibilidade_reducao_uso_1a5]
 - Exemplo:
    4 : 3 = 3 
    5 : 5 = 5
    6 : 4 = 4

nota_baixo_esforco = 6 - esforco_1a5
 - esforco_1a5 = coluna [esforco_1a5]
 - Exemplo:
   4 : 2 = 6 - 2 = 4
   5 : 1 = 6 - 1 = 5
   6 : 1 = 6 - 1 = 5

utilidade = (peso_economia * nota_economia) + (peso_conforto * nota_conforto) + (peso_flexibilidade * nota_flexibilidade) + (peso_baixo_esforco * nota_baixo_esforco)
 - peso_economia = 0.55
 - peso_conforto = 0.15
 - peso_flexibilidade = 0.2
 - peso_baixo_esforco = 0.1
 - Exemplo:
   4 : (0.55 * 5) + (0.15 * 4) + (0.2 * 3) + (0.1 * 4) = 4.35
   5 : (0.55 * 4) + (0.15 * 4) + (0.2 * 5) + (0.1 * 5) = 4.3
   6 : (0.55 * 3) + (0.15 * 4) + (0.2 * 4) + (0.1 * 5) = 3.55

lista final [4, 5, 6]

*leituraDados.py:*

- def lerDados : função responsável pela leitura do dataset, aqui ela irá ler os dados referentes apenas a residência escolhida, e não todos os dados do arquivo csv

- def transformar : função responsável por transformar a escolha de residência do usuário, ou seja, transforma de int para o id cadastrado no arquivo csv. Exemplo: 1 -> R01

- def conversao_pesos : função responsável por transfomar os pesos de cada residência de texto para float, para poderem serem utilizados posteriormente na execução do programa. Exemplo:
de:

peso_economia : "0.55"
peso_conforto : "0.15"
peso_flexibilidade : "0.2"
peso_baixo_esforco : "0.1"

para:

peso_economia : 0.55
peso_conforto : 0.15
peso_flexibilidade : 0.2
peso_baixo_esforco : 0.1

- def calculo_consumo : função responsável por calcular o quanto uma casa gasta, assim podemos posteriormente usar ela para podermos calcular quanto ficou o gasto da casa após as escolhas do usuário. Exemplo:

valor = 3.991 + 6.852 + 3.465 + 0.702 + 0.48 + 0.494 = 15.98

- def converter_meta : função responsável apenas pela conversão da coluna [meta_consumo_diario_kwh] de texto para float

*Estado interno do agente*

O estado interno é criado no arquivo 'principal.py' e é responsável por armazenar as informações da residência durante a execução do agente.

Ele é composto pelos seguintes elementos:

- residencia : identificador da residência escolhida.
- consumo : consumo diário estimado, atualizado conforme as sugestões aceitas.
- apresentados : lista de equipamentos cujas sugestões já foram apresentadas ao usuário.
- aceitos : lista de equipamentos cujas sugestões foram aceitas.
- rejeitados : lista de equipamentos cujas sugestões foram rejeitadas.
- pendentes : lista de equipamentos cujas decisões foram adiadas.
- podem_ser_apresentadas : lista inicial de oportunidades elegíveis, ordenadas pela utilidade calculada.

Quando uma sugestão é aceita seu identificador é registrado em 'aceitos' e sua economia potencial é descontada do consumo estimado. Quando é rejeitada, seu identificador é registrado em 'rejeitados', sem alterar o consumo. Caso o usuário escolha decidir depois, o identificador é armazenado em 'pendentes'.

Posteriormente, o usuário pode decidir sobre as oportunidades pendentes. Após a decisão, elas são retiradas dessa lista e transferidas para 'aceitos' ou 'rejeitados', conforme a escolha.

*principal.py:*

Arquivo principal onde o programa é executado, seguindo a seguinte ordem:

- Escolha da residência que o agente irá analisar (1–10).
- Leitura dos dados referentes à residência escolhida.
- Apresentação dos dados principais da residência.
- Percepção dos equipamentos passíveis de mudança.
- Conversão dos dados necessários e cálculo da utilidade e do consumo.
- Criação do estado interno do agente.
- Apresentação das sugestões e escolha do usuário entre aceitar, rejeitar ou decidir depois.
- Armazenamento das decisões no estado interno e atualização do consumo quando uma sugestão é aceita.
- Possibilidade de decidir sobre as sugestões que ficaram pendentes.
- Apresentação do feedback final, incluindo sugestões aceitas, rejeitadas e pendentes, além do consumo atualizado e da comparação com a meta.
- Reinício ou finalização do programa.