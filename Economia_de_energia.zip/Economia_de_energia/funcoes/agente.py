def conversao_linha_equipamento(linha):
    equipamento = dict(linha)

    equipamento["reducao_uso"] = (equipamento["reducao_uso"].strip().lower() == "true")

    equipamento["impacto_conforto_1a5"] = int(equipamento["impacto_conforto_1a5"])
    
    equipamento["flexibilidade_reducao_uso_1a5"] = int(equipamento["flexibilidade_reducao_uso_1a5"])
    
    equipamento["esforco_1a5"] = int(equipamento["esforco_1a5"])

    equipamento["economia_potencial_reducao_kwh"] = float(equipamento["economia_potencial_reducao_kwh"])

    return equipamento

def perceber(dataset):
    possiveis_opcoes = []
    equipamentos = []

    for linha in dataset:

        # conversão dos dados do dataset de texto para int/float/booleano/etc
        equipamento_convertido = conversao_linha_equipamento(linha)
        equipamentos.append(equipamento_convertido)

    for equipamento in equipamentos:
        #procurar quais sao validas e retornar possiveis_opcoes para contexto 
        # (foi usado varios if's para ficar melhor a visualizacao, e não uma linha extensa com and)
        if equipamento["reducao_uso"] is True: 
            if equipamento["economia_potencial_reducao_kwh"] > 0:
                if equipamento["essencialidade"] != "essencial":
                    if equipamento["impacto_conforto_1a5"] <= 3:

                        dados = {
                            "equipamento_id": equipamento["equipamento_id"],
                            "equipamento": equipamento["equipamento"],
                            "categoria": equipamento["categoria"],
                            "economia_potencial_reducao_kwh": equipamento["economia_potencial_reducao_kwh"],
                            "impacto_conforto_1a5": equipamento["impacto_conforto_1a5"],
                            "flexibilidade_reducao_uso_1a5": equipamento["flexibilidade_reducao_uso_1a5"],
                            "esforco_1a5": equipamento["esforco_1a5"]
                        }

                        possiveis_opcoes.append(dados)

    return possiveis_opcoes

def definir_descricao(equipamento, categoria):

    if categoria == "cozinha":
        if equipamento == "Geladeira":
            return "Evite abrir a porta frequentemente e verifique se ela está bem fechada."
        
        elif equipamento == "Forno elétrico":
            return "Evite utilizá-lo por períodos prolongados quando não for necessário."

    elif categoria == "climatizacao":
        if equipamento == "Ar-condicionado":
            return "Reduza o tempo de utilização e ajuste a temperatura para evitar consumo excessivo."
        
        elif equipamento == "Ventilador":
            return "Desligue quando não houver necessidade de ventilação."

    elif categoria == "higiene":
        if equipamento == "Chuveiro elétrico":
            return "Reduza o tempo dos banhos para diminuir o consumo de energia."

    elif categoria == "lavanderia":
        if equipamento == "Máquina de lavar":
            return "Procure utilizar a máquina com cargas completas, evitando lavagens desnecessárias."

    elif categoria == "entretenimento":
        if equipamento == "Televisão":
            return "Desligue a televisão quando não estiver assistindo."

    elif categoria == "iluminacao":
        if equipamento == "Iluminação LED":
            return "Apague as luzes dos ambientes que não estão sendo utilizados."

    elif categoria == "trabalho_estudo":
        if equipamento == "Computador":
            return "Desligue o computador ou suspenda suas atividades quando não estiver sendo utilizado." 

    return "Procure reduzir o uso do equipamento quando não for necessário."                   


def calculo_utilidade(contexto, pesos):
    lista = []

    maior_economia_elegivel = max(oportunidade['economia_potencial_reducao_kwh'] for oportunidade in contexto)

    for opcao in contexto:
        nota_economia = 1 + 4 * (opcao["economia_potencial_reducao_kwh"] / maior_economia_elegivel)
        nota_conforto = 6 - opcao["impacto_conforto_1a5"]
        nota_flexibilidade = opcao["flexibilidade_reducao_uso_1a5"]
        nota_baixo_esforco = 6 - opcao["esforco_1a5"]

        utilidade = (
            (pesos["peso_economia"] * nota_economia)
            + (pesos["peso_conforto"] * nota_conforto)
            + (pesos["peso_flexibilidade"] * nota_flexibilidade)
            + (pesos["peso_baixo_esforco"] * nota_baixo_esforco)
        )

        opcao_calculada = {
            "equipamento_id" : opcao["equipamento_id"],
            "equipamento" : opcao["equipamento"],
            "categoria" : opcao["categoria"],
            "economia_potencial_reducao_kwh" : opcao["economia_potencial_reducao_kwh"],
            "impacto_conforto_1a5" : opcao["impacto_conforto_1a5"],
            "flexibilidade_reducao_uso_1a5" : opcao["flexibilidade_reducao_uso_1a5"],
            "esforco_1a5" : opcao["esforco_1a5"],
            "utilidade" : utilidade,
            "descricao" : definir_descricao(opcao["equipamento"], opcao["categoria"])
        }

        lista.append(opcao_calculada)

    lista_ordenada = sorted(lista, key=lambda opcao : opcao["utilidade"], reverse=True)

    return lista_ordenada
