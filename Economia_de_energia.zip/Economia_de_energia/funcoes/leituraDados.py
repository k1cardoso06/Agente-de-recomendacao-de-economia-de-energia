import csv
from pathlib import Path

def lerDados(residencia):
    pasta_atual = Path(__file__).resolve().parent
    caminho = pasta_atual.parent / 'dados' / 'dataset_consumo_energia.csv'
    dados = []

    with open(caminho, 'r', encoding='utf-8-sig') as arquivo:
            leitor = csv.DictReader(arquivo)
            for linha in leitor:
                if linha["residencia_id"] == residencia:
                    dados.append(linha)
    
    return dados

def transformar(opcao):
    residencia = f'R{opcao:02d}' # 1 -> R01
    return residencia

def conversao_pesos(dataset):
    valores = {
        "peso_economia" : float(dataset[0]["peso_economia"]),
        "peso_conforto" : float(dataset[0]["peso_conforto"]),
        "peso_flexibilidade" : float(dataset[0]["peso_flexibilidade"]),
        "peso_baixo_esforco" : float(dataset[0]["peso_baixo_esforco"])
    }

    return valores

def calculo_consumo(dataset):
    valor = 0

    for linha in dataset:
        linha["consumo_diario_estimado_kwh"] = float(linha["consumo_diario_estimado_kwh"])

        valor += linha["consumo_diario_estimado_kwh"]

    return valor

def converter_meta(dataset):

    return float(dataset[0]['meta_consumo_diario_kwh'])