from .leituraDados import (lerDados, transformar, conversao_pesos, calculo_consumo, converter_meta)
from .agente import (perceber, calculo_utilidade)